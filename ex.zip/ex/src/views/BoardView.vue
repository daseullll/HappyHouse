<template>
  <div class="container outer">
    <h2 class="text-center"></h2>
    <router-view></router-view>
  </div>
</template>
