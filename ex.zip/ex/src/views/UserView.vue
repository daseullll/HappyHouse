<template>
  <div class="container outer">
    <div class="title-container">
      <span
        ><img class="titleIcon" src="@/assets/images/small-hap.png" />
      </span>
      <span class="underline title fs-48 notoBold">마이페이지</span>
    </div>
    <router-view></router-view>
  </div>
</template>
